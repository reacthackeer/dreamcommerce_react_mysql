import React from 'react';

const sqlGenerator = () => {
    return (
        <div>
            <h1>Hello world</h1>
        </div>
    );
};

export default sqlGenerator;