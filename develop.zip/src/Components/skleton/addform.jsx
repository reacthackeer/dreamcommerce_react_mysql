// add section -> name, img__src, uid
// add topCategory -> name, uid, src, up
// add category -> name, parent__father, uid, src, up
// add collection -> name, parent, uid, src, up
// add brands -> brand, uid, src
// 