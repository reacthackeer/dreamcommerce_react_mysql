
// const {DataTypes} = require('sequelize');
// const sequelize = require('../config/database');

// const Product = sequelize.define('product',{
//     ID: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     },
//     product__id: DataTypes.STRING, 
//     brand: DataTypes.STRING ,
//     child: DataTypes.STRING, 
//     parent: DataTypes.STRING, 
//     parent__father: DataTypes.STRING,  
//     up: DataTypes.STRING,  
//     visible__url:  DataTypes.STRING, 
//     visible:  DataTypes.STRING,  
//     total__sell:  DataTypes.INTEGER, 
//     quantity: DataTypes.INTEGER,  
//     infos: DataTypes.JSON,  
// },{
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = Product;