
// const {DataTypes} = require('sequelize');
// const sequelize = require('../config/database'); 

// const Cart = sequelize.define('cart',{
//     ID: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     },
//     product__id:  DataTypes.STRING,
//     quantity: DataTypes.INTEGER,
//     user__id: DataTypes.STRING,
//     id__user__id: DataTypes.STRING
// },{
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = Cart;