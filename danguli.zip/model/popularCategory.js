// const {DataTypes} = require('sequelize');
// const sequelize = require('../config/database');   

// const PopularCategory = sequelize.define('popularCategory',{
//     ID: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     },
//     name: {
//         type: STRING,
//         allowNull: false,
//         unique: true
//     },
//     link: DataTypes.STRING
// },{
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = PopularCategory;