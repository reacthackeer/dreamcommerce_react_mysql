
// const {DataTypes, STRING} = require('sequelize');
// const sequelize = require('../config/database');   

// const Upazilla = sequelize.define('upazilla',{
//     id: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     },
//     district_id: DataTypes.INTEGER,
//     name: DataTypes.STRING,
//     bn_name: DataTypes.STRING,
//     url: DataTypes.STRING,
//     name_id: {
//         type: DataTypes.STRING,
//         unique: true
//     }
// },{
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = Upazilla;