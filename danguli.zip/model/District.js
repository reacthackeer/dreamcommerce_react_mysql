// const {DataTypes, STRING} = require('sequelize');
// const sequelize = require('../config/database');   

// const District = sequelize.define('district',{
//     id: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     },
//     division_id: DataTypes.INTEGER,
//     name: DataTypes.STRING,
//     bn_name: DataTypes.STRING,
//     lat: DataTypes.STRING,
//     lon: DataTypes.STRING,
//     url: DataTypes.STRING,
//     name_id: {
//         type: DataTypes.STRING,
//         unique: true
//     }
// },{
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = District;