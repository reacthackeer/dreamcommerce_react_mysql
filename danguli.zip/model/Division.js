
// const {DataTypes, STRING} = require('sequelize');
// const sequelize = require('../config/database');   

// const Division = sequelize.define('division',{
//     id: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     }, 
//     name: {
//         type: DataTypes.STRING, 
//         unique: true
//     },
//     bn_name: DataTypes.STRING, 
//     url: {
//         type:  DataTypes.STRING,
//         allowNull:  true,
//         defaultValue: 'empty'
//     }
// },{
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = Division;