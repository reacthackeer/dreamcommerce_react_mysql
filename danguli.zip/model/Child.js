
// const {DataTypes, STRING} = require('sequelize');
// const sequelize = require('../config/database');  

// const Child = sequelize.define('child',{
//     ID: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     },
//     name:  DataTypes.STRING,
//     parent:  DataTypes.STRING,
//     uid: DataTypes.STRING,
//     src: DataTypes.STRING,
//     up: DataTypes.STRING,
//     name_parent_up: {
//         type: STRING,
//         allowNull: false,
//         unique: true
//     }
// },{
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = Child;