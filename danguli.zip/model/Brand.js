// const {DataTypes} = require('sequelize');
// const sequelize = require('../config/database'); 

// const Brand = sequelize.define('brand',{
//     ID: {
//         type: DataTypes.INTEGER,
//         primaryKey: true,
//         autoIncrement: true
//     },
//     brand: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         unique: true
//     },
//     uid: DataTypes.INTEGER,
//     src: DataTypes.STRING, 
// },{
//     timestamps: true,
//     createdAt: 'created_at',
//     updatedAt: 'updated_at'
// });

// module.exports = Brand;