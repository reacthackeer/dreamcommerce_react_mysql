let wishlist = {user__id, product__id, quantity};
let users = {name, email, phone, password, user__id};
let brand = {brand, uid, src}
let browsing__history = {user__id, product__id}
let cart = {user__id, product__id, quantity};